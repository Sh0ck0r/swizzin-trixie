#!/bin/bash
echo "Installing RAR and UNRAR from official RARLAB archive..."

cd "$(dirname "$0")"
tar -xzf rarlinux-x64-712b1.tar.gz
cd rar

sudo install -m755 rar unrar /usr/local/bin/

echo "✅ RAR and UNRAR installed successfully to /usr/local/bin"
